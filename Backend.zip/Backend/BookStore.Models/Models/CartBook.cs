﻿namespace BookStore.Models.Models
{
    public class CartBook
    {
        public string BookName { get; set; }
        public decimal Price { get; set; }
    }
}
